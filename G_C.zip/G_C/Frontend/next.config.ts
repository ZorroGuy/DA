import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  cacheComponents: true,
  partialPrefetching: true,
  reactCompiler: true,
  // experimental: {
  //   middlewareClientMaxBodySize: "50mb",
  // },
  async redirects() {
    return [
      {
        source: "/",
        destination: "/doctor-ocr", 
        permanent: false, 
      },
    ];
  },
  async rewrites() {
    return [
      {
        source: "/api1/:path*",
        destination:
          "",
      },
      {
        source: "/api2/:path*",
        destination: "",
      },
      {
        source: "/:path*",
        destination: "",
      },
      {
        source: "/api3/:path*",
        destination: "",
      },
    ];
  },
};

export default nextConfig;
