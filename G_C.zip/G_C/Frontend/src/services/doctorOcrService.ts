import { payloadData } from "../app/constants/mock";

export interface DmsMetadataOverrides {
  imageId?: string;
  uniqueId?: string;
  appId?: string;
  branchCode?: string;
  branch?: string;
  imageCategory?: string;
  imageSubCategory?: string;
  latLong?: string;
  user?: string;
  createdBy?: string;
  modifiedBy?: string;
  keyId?: string[];
  keyValue?: string[];
}

const getFormattedDate = (): string => {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, "0");
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const year = now.getFullYear();
  return `${day}/${month}/${year}`;
};

export const uploadPdfToDMS = async (
  pdfFile: File,
  checksum: string,
  pageCount: number,
  overrides: DmsMetadataOverrides = {}
) => {
  const today = getFormattedDate();

  const metadata = {
    imageId: overrides.imageId ?? "36857835bf215514835ab810",
    uniqueId: overrides.uniqueId ?? "41559856bf",
    appId: overrides.appId ?? "780923",
    sourceSys: "SCF",
    branchCode: overrides.branchCode ?? "BGLR",
    branch: overrides.branch ?? "Bangalore",
    vertical: "SCF",
    module: "Registration",
    stage: "FI",
    imageCategory: overrides.imageCategory ?? "PAN Card",
    imageSubCategory: overrides.imageSubCategory ?? "DRIVING LICENCE",
    status: "1",
    fileName: pdfFile.name,
    latLong: overrides.latLong ?? "242-12344",
    imageSrc: "TAB1",
    imageSrcId: "23452347",
    format: "pdf",
    user: overrides.user ?? "107094",
    size: String(pdfFile.size),
    page: String(pageCount),
    createdBy: overrides.createdBy ?? "SCFUser",
    createdDate: today,
    modifiedBy: overrides.modifiedBy ?? "A834",
    modifiedDate: today,
    checkSum: checksum,
    keyId: overrides.keyId ?? [],
    keyValue: overrides.keyValue ?? [],
  };

  const formData = new FormData();
  formData.append("Text", JSON.stringify(metadata));
  formData.append("File", pdfFile, pdfFile.name);

  const response = await fetch("/api/dmsupload", {
    method: "POST",
    body: formData,
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "DMS Upload Failed");
  }

  return result;
};

// export const getDoctorDetails = async (dmsIDSample: string) => {
//   const payload = {
//     ...payloadData,
//     dms_id: dmsIDSample,
//   };
export const getDoctorDetails = async (dmsId: string,checksum: string) => {
  const payload = {
    ...payloadData,
    dms_id: dmsId,
    checksum:checksum
  };

  const response = await fetch("/api/doctorocr", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result.error || "Doctor OCR Failed");
  }

  return result;
};