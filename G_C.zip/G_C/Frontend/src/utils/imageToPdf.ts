import jsPDF from "jspdf";

export const convertImagesToPdf = async (files: File[]): Promise<File> => {
  const pdf = new jsPDF({
    orientation: "portrait",

    unit: "mm",

    format: "a4",
  });

  for (let i = 0; i < files.length; i++) {
    const file = files[i];

    const imageData = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        if (typeof reader.result === "string") {
          resolve(reader.result);
        } else {
          reject(new Error("Unable to read image"));
        }
      };

      reader.onerror = () => reject(new Error("Image reading failed"));

      reader.readAsDataURL(file);
    });

    const image = new Image();

    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();

      image.onerror = () => reject(new Error("Invalid image"));

      image.src = imageData;
    });

    if (i > 0) {
      pdf.addPage();
    }

    const pageWidth = 210;

    const pageHeight = 297;

    const margin = 10;

    const availableWidth = pageWidth - margin * 2;

    const availableHeight = pageHeight - margin * 2;

    const ratio = Math.min(
      availableWidth / image.width,

      availableHeight / image.height,
    );

    const width = image.width * ratio;

    const height = image.height * ratio;

    const x = (pageWidth - width) / 2;

    const y = (pageHeight - height) / 2;

    const format = file.type === "image/png" ? "PNG" : "JPEG";

    pdf.addImage(imageData, format, x, y, width, height);
  }

  const pdfBlob = pdf.output("blob");

  return new File(
    [pdfBlob],

    "uploaded_images.pdf",

    { type: "application/pdf" },
  );
};

export const generateSHA1 = async (file: File): Promise<string> => {
  const buffer = await file.arrayBuffer();
 
  const hash = await crypto.subtle.digest("SHA-1", buffer);
 
  return Array.from(new Uint8Array(hash))
    .map(byte => byte.toString(16).padStart(2, "0"))
    .join("");
};

export const downloadPdf = (file: File) => {
  const url = URL.createObjectURL(file);
 
  const link = document.createElement("a");
  link.href = url;
  link.download = file.name;
 
  document.body.appendChild(link);
  link.click();
 
  document.body.removeChild(link);
 
  URL.revokeObjectURL(url);
};