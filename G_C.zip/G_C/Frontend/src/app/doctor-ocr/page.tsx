"use client";
import * as React from "react";
import { Alert,Box, Container, Snackbar } from "@mui/material";
import DoctorImageUpload from "../components/uploadImage/DoctorImageUpload";
import DoctorForm from "../components/doctorform/DoctorForm";
import type {
  OcrDoctor,
  DoctorSubmission,
} from "../components/doctorform/types";
import {
  convertImagesToPdf,
  generateSHA1,
  downloadPdf,
} from "../../utils/imageToPdf";
import {
  uploadPdfToDMS,
  getDoctorDetails,
} from "../../services/doctorOcrService";
import toast from "react-hot-toast";

const INVALID_PHOTO =
  "Not a valid photo. Try uploading a clear picture with all mandatory details like Name, Number and Degree.";
const API_FAIL = "Unable to process image. Please try again later.";

export default function DoctorOcrPage() {
  const [processing, setProcessing] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [doctors, setDoctors] = React.useState<OcrDoctor[]>([]);
  const [submitError, setSubmitError] = React.useState<string | null>(null);
  const [submitting, setSubmitting] = React.useState(false);

  const [toastState, setToastState] = React.useState<{
    open: boolean;
    message: string;
    severity: "success" | "error" | "info";
  }>({
    open: false,
    message: "",
    severity: "success",
  });
  const handleCloseToast = () => {
    setToastState((prev) => ({ ...prev, open: false }));
  };

  const handleSubmit = async (files: File[]) => {
    try {
      if (!files.length) {
        setError("Please select at least one image.");
        return;
      }

      setProcessing(true);
      setError(null);

      const pdfFile = await convertImagesToPdf(files);
      //downloadPdf(pdfFile);

      const checksum = await generateSHA1(pdfFile);

      const pageCount = files.length;

      const dmsResponse = await uploadPdfToDMS(pdfFile, checksum, pageCount);

      console.log("DMS Response:", dmsResponse);

      const dmsId = dmsResponse?.dms_id;

      console.log("DMS ID:", dmsId);

      if (!dmsId) {
        throw new Error("DMS ID not received");
      }

      const doctorResponse = await getDoctorDetails(dmsId, checksum);

      console.log("Doctor OCR Response:", doctorResponse);
      const extractedDoctors: OcrDoctor[] =
        doctorResponse?.response?.doctors?.map((doctor: any) => ({
          name: doctor.name ?? "",
          degree: doctor.degree ?? "",
          speciality: doctor.speciality ?? "",
          contact_numbers: doctor.contact_numbers ?? [],
          registration_no: doctor.registration_no,
          registration_year: doctor.registration_year,
          years_of_experience: doctor.years_of_experience,
          medical_council: doctor.medical_council,
          practice_type: doctor.practice_type,
          clinic_hospital_name: doctor.clinic_hospital_name,
          clinic_hospital_address: doctor.clinic_hospital_address,
          clinic_hospital_pincode: doctor.clinic_hospital_pincode,
          is_valid: doctor.is_valid,
          invalid_fields: doctor.invalid_fields ?? [],
        })) ?? [];

      const readable = extractedDoctors.filter((d) => d.name?.trim());

      if (!readable.length) {
        setError(INVALID_PHOTO);
        setDoctors([]);
        return;
      }

      setDoctors(extractedDoctors);
    } catch (e) {
      setError(API_FAIL);
    } finally {
      setProcessing(false);
    }
  };

  const handleFormSubmit = async (items: DoctorSubmission[]) => {
    try {
      setSubmitting(true);
      setSubmitError(null);

      const payload = {
        api_key: "doctor_detail_entry",

        created_employee_id: "CF41272",

        source_channel: "SSA",

        ocrid: "123",

        submitted_data: items.map((item) => ({
          name: item.submitted.name,
          degree: item.submitted.degree,
          speciality: item.submitted.speciality,

          contact_numbers: item.submitted.contactNumber
            ? [item.submitted.contactNumber]
            : [],

          registration_no: item.submitted.registrationNo || null,

          registration_year: item.submitted.registrationYear
            ? Number(item.submitted.registrationYear)
            : null,

          years_of_experience: item.submitted.yearsOfExperience
            ? Number(item.submitted.yearsOfExperience)
            : null,

          medical_council: item.submitted.medicalCouncil || null,

          practice_type: item.submitted.practiceType || null,

          clinic_hospital_name: item.submitted.clinicHospitalName || null,

          clinic_hospital_address: item.submitted.clinicHospitalAddress || null,

          clinic_hospital_pincode: item.submitted.clinicHospitalPincode || null,
        })),

        original_data: items.map((item) => item.original),
      };

      console.log("Payload:", payload);

      const response = await fetch("/api/doctordetails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
      const result = await response.json();

      if (response.status === 409) {
        setSubmitError(result.message || "Duplicate Data entry");
        return;
      }

      if (!response.ok) {
        throw new Error(result.message || "Failed to save doctors");
      }

      // toast.success(`Successfully saved ${result.doctor_count} doctor(s)`);
      setToastState({
    open: true,
    message: `Successfully saved ${result.doctor_count} doctor(s)`,
    severity: "success",
  });
      handleResetToUpload();
    } catch (error) {
      setSubmitError(
        error instanceof Error ? error.message : "Failed to save doctors",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetToUpload = () => {
    setDoctors([]);
    setError(null);
    setSubmitError(null);
  };
  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F3F6FB",
      }}
    >
      <Container
        maxWidth="lg"
        sx={{
          py: { xs: 3, md: 6 },
        }}
      >
        {doctors.length > 0 ? (
          <DoctorForm
            doctors={doctors}
            onSubmit={handleFormSubmit}
            isSubmitting={submitting}
            submitError={submitError}
           // onBack={handleResetToUpload}
          />
        ) : (
          <DoctorImageUpload
            onSubmit={handleSubmit}
            isProcessing={processing}
            errorMessage={error}
          />
        )}
      </Container>

      <Snackbar
        open={toastState.open}
        autoHideDuration={4000}
        onClose={handleCloseToast}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseToast}
          severity={toastState.severity}
          variant="filled"
          sx={{ width: "100%" }}
        >
          {toastState.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
