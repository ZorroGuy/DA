import type { DoctorFormValues } from "./types";

export const BRAND_BLUE = "#005BAA";

export const DEGREE_OPTIONS = [
  "MBBS",
  "MBBS MD",
  "MBBS MS",
  "BDS",
  "BDS MDS",
  "BHMS",
  "BAMS",
  "Ayurvedha",
  "Physiotherapist",
  "Other",
];

export const SPECIALITY_OPTIONS = [
  "General Physician",
  "Eye Specialist",
  "Surgeon",
  "Paediatrician",
  "Gynaecologist",
  "Dermatologist",
  "Orthopaedic",
  "Cardiologist",
  "Neurologist",
  "ENT Specialist",
  "Dentist",
  "Other",
];

export const PRACTICE_OPTIONS = ["Clinic", "Hospital"];

export type OptionsKey = "degree" | "speciality" | "practice";

export interface FieldConfig {
  name: keyof DoctorFormValues;
  label: string;
  type: "text" | "select" | "radio" | "textarea";
  required?: boolean;
  optionsKey?: OptionsKey;
  numeric?: boolean;
  maxLength?: number;
  fullWidth?: boolean;
  visibleIf?: (v: DoctorFormValues) => boolean;
}

export const DOCTOR_FIELDS: FieldConfig[] = [
  { name: "name", label: "Name", type: "text", required: true },
  {
    name: "degree",
    label: "Degree",
    type: "select",
    required: true,
    optionsKey: "degree",
  },
  {
    name: "degreeOther",
    label: "Specify Degree",
    type: "text",
    required: true,
    fullWidth: true,
    visibleIf: (v) => v.degree === "Other",
  },
  {
    name: "speciality",
    label: "Speciality",
    type: "select",
    optionsKey: "speciality",
  },
  {
    name: "specialityOther",
    label: "Specify Speciality",
    type: "text",
    fullWidth: true,
    visibleIf: (v) => v.speciality === "Other",
  },
  {
    name: "contactNumber",
    label: "Contact Number",
    type: "text",
    required: true,
    numeric: true,
    maxLength: 10,
  },
  { name: "registrationNo", label: "Registration No", type: "text" },
  {
    name: "practiceType",
    label: "Clinic/Hospital",
    type: "radio",
    optionsKey: "practice",
  },
  { name: "clinicHospitalName", label: "Clinic/Hospital Name", type: "text" },
  {
    name: "clinicHospitalAddress",
    label: "Clinic/Hospital Address",
    type: "textarea",
    fullWidth: true,
  },
  {
    name: "clinicHospitalPincode",
    label: "Clinic/Hospital Pincode",
    type: "text",
    required: true,
    numeric: true,
    maxLength: 6,
  },
  {
    name: "registrationYear",
    label: "Registration Year",
    type: "text",
    numeric: true,
    maxLength: 4,
  },
  {
    name: "yearsOfExperience",
    label: "Years of Experience",
    type: "text",
    numeric: true,
    maxLength: 2,
  },
  { name: "medicalCouncil", label: "Medical Council", type: "text" },
];

/** OCR key -> readable label, used in the "couldn't read" warning. */
export const OCR_FIELD_LABELS: Record<string, string> = {
  name: "Name",
  degree: "Degree",
  speciality: "Speciality",
  contact_numbers: "Contact Number",
  registration_no: "Registration No",
  registration_year: "Registration Year",
  years_of_experience: "Years of Experience",
  medical_council: "Medical Council",
  practice_type: "Clinic/Hospital",
  clinic_hospital_name: "Clinic/Hospital Name",
  clinic_hospital_address: "Clinic/Hospital Address",
  clinic_hospital_pincode: "Pincode",
};
