import { z } from "zod";

export interface SchemaOptions {
  isPincodeAllowed?: (pincode: string) => boolean;
}

export const createDoctorSchema = ({ isPincodeAllowed }: SchemaOptions = {}) =>
  z
    .object({
      name: z.string().trim().min(1, "Name is required"),
      degree: z.string().min(1, "Degree is required"),
      degreeOther: z.string(),
      speciality: z.string(),
      specialityOther: z.string(),
      contactNumber: z
        .string()
        .min(1, "Contact number is required")
        .regex(/^[6-9]\d{9}$/, "Please enter a valid mobile number."),
      registrationNo: z.string(),
      practiceType: z.string(),
      clinicHospitalName: z.string(),
      clinicHospitalAddress: z.string(),
      clinicHospitalPincode: z
        .string()
        .min(1, "Pincode is required")
        .regex(/^\d{6}$/, "Please enter a valid 6-digit pincode.")
        .refine(
          (p) => !isPincodeAllowed || !/^\d{6}$/.test(p) || isPincodeAllowed(p),
          "Please enter a valid CSEL pincode.",
        ),
      registrationYear: z
        .string()
        .regex(/^(\d{4})?$/, "Enter a valid 4-digit year"),
      yearsOfExperience: z
        .string()
        .regex(/^(\d{1,2})?$/, "Enter valid years of experience"),
      medicalCouncil: z.string(),
    })
    .superRefine((v, ctx) => {
      if (v.degree === "Other" && !v.degreeOther.trim()) {
        ctx.addIssue({
          code: "custom",
          path: ["degreeOther"],
          message: "Please specify the degree",
        });
      }
    });

export const createFormSchema = (opts: SchemaOptions = {}) =>
  z.object({ doctors: z.array(createDoctorSchema(opts)).min(1) });
