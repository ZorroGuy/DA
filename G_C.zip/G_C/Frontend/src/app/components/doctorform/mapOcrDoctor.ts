import type { DoctorFormValues, DoctorSubmitted, OcrDoctor } from "./types";

const alnum = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
const tokens = (s: string) =>
  new Set(
    s
      .split(/[,;/&()\s]+/)
      .map(alnum)
      .filter(Boolean),
  );
const sameSet = (a: Set<string>, b: Set<string>) =>
  a.size === b.size && [...a].every((x) => b.has(x));

function matchDegree(raw: string | null, options: string[]) {
  if (!raw?.trim()) return { value: "", other: "" };
  const t = tokens(raw);
  const hit = options.find((o) => o !== "Other" && sameSet(tokens(o), t));
  return hit
    ? { value: hit, other: "" }
    : { value: "Other", other: raw.trim() };
}

function matchSpeciality(raw: string | null, options: string[]) {
  if (!raw?.trim()) return { value: "", other: "" };
  const n = alnum(raw);
  const hit = options.find((o) => o !== "Other" && alnum(o) === n);
  return hit
    ? { value: hit, other: "" }
    : { value: "Other", other: raw.trim() };
}

function firstPhone(numbers: string[] | null | undefined) {
  const digits = (numbers?.[0] ?? "").replace(/\D/g, "");
  return digits.length > 10 ? digits.slice(-10) : digits;
}

function matchPractice(raw: string | null, options: string[]) {
  const s = (raw ?? "").toLowerCase();
  return options.find((o) => s.includes(o.toLowerCase())) ?? "";
}

const str = (v: unknown) =>
  v === null || v === undefined ? "" : String(v).trim();

export function mapOcrDoctor(
  d: OcrDoctor,
  opts: {
    degreeOptions: string[];
    specialityOptions: string[];
    practiceOptions: string[];
  },
): DoctorFormValues {
  const degree = matchDegree(d.degree, opts.degreeOptions);
  const speciality = matchSpeciality(d.speciality, opts.specialityOptions);

  return {
    name: str(d.name),
    degree: degree.value,
    degreeOther: degree.other,
    speciality: speciality.value,
    specialityOther: speciality.other,
    contactNumber: firstPhone(d.contact_numbers),
    registrationNo: str(d.registration_no),
    practiceType: matchPractice(d.practice_type, opts.practiceOptions),
    clinicHospitalName: str(d.clinic_hospital_name),
    clinicHospitalAddress: str(d.clinic_hospital_address),
    clinicHospitalPincode: str(d.clinic_hospital_pincode)
      .replace(/\D/g, "")
      .slice(0, 6),
    registrationYear: str(d.registration_year),
    yearsOfExperience: str(d.years_of_experience),
    medicalCouncil: str(d.medical_council),
  };
}

export function toSubmitted(v: DoctorFormValues): DoctorSubmitted {
  const { degreeOther, specialityOther, ...rest } = v;
  return {
    ...rest,
    name: v.name.trim(),
    degree: v.degree === "Other" ? degreeOther.trim() : v.degree,
    speciality:
      v.speciality === "Other" ? specialityOther.trim() : v.speciality,
  };
}
