"use client";

import * as React from "react";
import { Alert, Box, Button, Typography } from "@mui/material";
import type { SxProps, Theme } from "@mui/material/styles";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import { useForm } from "react-hook-form";
import type { Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import DoctorCard from "./DoctorCard";
import {
  BRAND_BLUE,
  DEGREE_OPTIONS,
  PRACTICE_OPTIONS,
  SPECIALITY_OPTIONS,
} from "./doctorForm.config";
import { mapOcrDoctor, toSubmitted } from "./mapOcrDoctor";
import { createFormSchema } from "./doctorForm.schema";
import type { DoctorSubmission, FormShape, OcrDoctor } from "./types";

export interface DoctorFormProps {
  doctors: OcrDoctor[];
  onSubmit: (items: DoctorSubmission[]) => void | Promise<void>;
  onBack?: () => void;
  isSubmitting?: boolean;
  submitError?: string | null;
  serverErrors?: Record<number, string>;
  degreeOptions?: string[];
  specialityOptions?: string[];
  practiceOptions?: string[];
  isPincodeAllowed?: (pincode: string) => boolean;
  submitLabel?: string;
  sx?: SxProps<Theme>;
}

const DoctorForm: React.FC<DoctorFormProps> = ({
  doctors,
  onSubmit,
  onBack,
  isSubmitting = false,
  submitError,
  serverErrors,
  degreeOptions = DEGREE_OPTIONS,
  specialityOptions = SPECIALITY_OPTIONS,
  practiceOptions = PRACTICE_OPTIONS,
  isPincodeAllowed,
  submitLabel = "Submit All Doctors",
  sx,
}) => {
  const formRef = React.useRef<HTMLFormElement>(null);
  const [showSummary, setShowSummary] = React.useState(false);

  const schema = React.useMemo(
    () => createFormSchema({ isPincodeAllowed }),
    [isPincodeAllowed],
  );

  const initial = React.useMemo<FormShape>(
    () => ({
      doctors: doctors.map((d) =>
        mapOcrDoctor(d, { degreeOptions, specialityOptions, practiceOptions }),
      ),
    }),
    [doctors, degreeOptions, specialityOptions, practiceOptions],
  );

  const { control, handleSubmit, reset, trigger } = useForm<FormShape>({
    resolver: zodResolver(schema) as unknown as Resolver<FormShape>,
    defaultValues: initial,
    mode: "onBlur",
  });

  React.useEffect(() => {
    reset(initial);
    void trigger();
  }, [initial, reset, trigger]);

  const submit = handleSubmit(
    async (data) => {
      setShowSummary(false);
      await onSubmit(
        data.doctors.map((v, i) => ({
          original: doctors[i],
          submitted: toSubmitted(v),
        })),
      );
    },
    () => {
      setShowSummary(true);
      requestAnimationFrame(() =>
        formRef.current
          ?.querySelector('[data-field-error="true"]')
          ?.scrollIntoView({ behavior: "smooth", block: "center" }),
      );
    },
  );

  const handleCancel = () => {
    reset(initial);
    setShowSummary(false);
  };

  const optionsMap = {
    degree: degreeOptions,
    speciality: specialityOptions,
    practice: practiceOptions,
  };

  return (
    <Box
      component="form"
      ref={formRef}
      noValidate
      onSubmit={submit}
      sx={[
        {
          display: "flex",
          flexDirection: "column",
          gap: 2,
          width: "100%",
          minHeight: "100vh",
          bgcolor: "#F5F7FB",
          p: { xs: 2, sm: 3 },
        },
        ...(Array.isArray(sx) ? sx : [sx]),
      ]}
    >
      <Box sx={{ mb: 1 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box
            sx={{
              width: 38,
              height: 38,
              borderRadius: "10px",
              bgcolor: "#E5EFFA",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: BRAND_BLUE,
            }}
          ></Box>

          <Box>
            <Typography
              sx={{
                fontWeight: 700,
                color: "#172033",
                fontSize: "1.2rem",
              }}
            >
              Doctor data capture
            </Typography>

            <Typography sx={{ color: "#718096", fontSize: "0.8rem" }}>
              {doctors.length === 1
                ? "We found 1 doctor in your image. Check the details and fix anything that looks wrong before you save."
                : `We found ${doctors.length} doctors in your image. Check each one and fix anything that looks wrong before you save.`}
            </Typography>
          </Box>
        </Box>
      </Box>

      {initial.doctors.map((_, i) => (
        <DoctorCard
          key={i}
          index={i}
          control={control}
          ocr={doctors[i]}
          optionsMap={optionsMap}
          serverError={serverErrors?.[i]}
          disabled={isSubmitting}
        />
      ))}

      {showSummary && (
        <Alert severity="error" sx={{ borderRadius: "10px" }}>
          Please complete all mandatory fields.
        </Alert>
      )}

      {submitError && (
        <Alert severity="error" sx={{ borderRadius: "10px" }}>
          {submitError}
        </Alert>
      )}

      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          pt: 2,
          borderTop: "1px solid #E5EAF1",
          mt: "auto",
        }}
      >
        <Button
          type="submit"
          variant="contained"
          disableElevation
          disabled={isSubmitting}
          sx={{
            bgcolor: BRAND_BLUE,
            borderRadius: "8px",
            width: { xs: "100%", sm: "auto" },
            px: { xs: 2, sm: 3 },
            py: { xs: 1.5, sm: 1.2 },
            fontSize: { xs: "0.875rem", sm: "1rem" },
            fontWeight: 700,
            textTransform: "none",
            "&:hover": {
              bgcolor: "#004A8C",
            },
          }}
        >
          {isSubmitting
            ? "Saving..."
            : doctors.length === 1
              ? "Save 1 doctor"
              : `Save ${doctors.length} doctors`}
        </Button>
      </Box>
    </Box>
  );
};

export default DoctorForm;
