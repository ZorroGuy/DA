export interface OcrDoctor {
  name: string | null;
  degree: string | null;
  speciality: string | null;
  contact_numbers: string[];
  registration_no: string | null;
  registration_year: number | string | null;
  years_of_experience: number | string | null;
  medical_council: string | null;
  practice_type: string | null;
  clinic_hospital_name: string | null;
  clinic_hospital_address: string | null;
  clinic_hospital_pincode: string | null;
  is_valid: boolean;
  invalid_fields: string[];
}

export interface DoctorFormValues {
  name: string;
  degree: string;
  degreeOther: string;
  speciality: string;
  specialityOther: string;
  contactNumber: string;
  registrationNo: string;
  practiceType: string; // "Clinic" | "Hospital" | ""
  clinicHospitalName: string;
  clinicHospitalAddress: string;
  clinicHospitalPincode: string;
  registrationYear: string;
  yearsOfExperience: string;
  medicalCouncil: string;
}

export interface FormShape {
  doctors: DoctorFormValues[];
}

export type DoctorSubmitted = Omit<
  DoctorFormValues,
  "degreeOther" | "specialityOther"
>;

export interface DoctorSubmission {
  original: OcrDoctor;
  submitted: DoctorSubmitted;
}
