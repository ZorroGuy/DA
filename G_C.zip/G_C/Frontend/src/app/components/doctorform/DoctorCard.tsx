"use client";

import * as React from "react";
import {
  Alert,
  Avatar,
  Box,
  Collapse,
  FormControl,
  FormControlLabel,
  FormHelperText,
  IconButton,
  MenuItem,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from "@mui/material";

import { Controller, useWatch } from "react-hook-form";
import type { Control, Path } from "react-hook-form";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import {
  BRAND_BLUE,
  DOCTOR_FIELDS,
  OCR_FIELD_LABELS,
} from "./doctorForm.config";
import type { OptionsKey } from "./doctorForm.config";
import type { DoctorFormValues, FormShape, OcrDoctor } from "./types";

interface DoctorCardProps {
  index: number;
  control: Control<FormShape>;
  ocr: OcrDoctor;
  optionsMap: Record<OptionsKey, string[]>;
  serverError?: string;
  disabled?: boolean;
  defaultExpanded?: boolean;
}

const inputSx = {
  "& .MuiOutlinedInput-root": {
    borderRadius: "8px",
    bgcolor: "#FFFFFF",
    fontSize: "0.85rem",
    minHeight: 38,

    "& fieldset": {
      borderColor: "#DCE3EC",
    },

    "&:hover fieldset": {
      borderColor: BRAND_BLUE,
    },

    "&.Mui-focused fieldset": {
      borderColor: BRAND_BLUE,
    },
  },

  "& .MuiInputBase-input": {
    py: 0.9,
  },

  "& .MuiSelect-select": {
    py: 0.9,
  },

  "& .MuiFormHelperText-root": {
    mx: 0,
  },
};

const getInitials = (name?: string | null) => {
  if (!name?.trim()) return "DR";

  const parts = name.trim().split(/\s+/);

  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }

  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
};

const DoctorCard: React.FC<DoctorCardProps> = ({
  index,
  control,
  ocr,
  optionsMap,
  serverError,
  disabled = false,
  defaultExpanded = true,
}) => {
  const [expanded, setExpanded] = React.useState(defaultExpanded);

  const values = useWatch({
    control,
    name: `doctors.${index}`,
  }) as DoctorFormValues | undefined;

  if (!values) return null;

  const unread = (ocr.invalid_fields ?? []).map(
    (key) => OCR_FIELD_LABELS[key] ?? key,
  );

  const initials = getInitials(values.name || ocr.name);

  return (
    <Box
      sx={{
        bgcolor: "#FFFFFF",
        border: "1px solid #E1E7EF",
        borderRadius: "10px",
        overflow: "hidden",
        boxShadow: "0 2px 7px rgba(20, 45, 80, 0.04)",
      }}
    >
      {/* Compact Header */}

      <Box
        onClick={() => setExpanded((prev) => !prev)}
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 1.5,
          px: 2,
          py: 1.25,
          bgcolor: "#F0F6FC",
          cursor: "pointer",
          userSelect: "none",
        }}
      >
        <Avatar
          sx={{
            width: 36,
            height: 36,
            bgcolor: "#FFFFFF",
            color: BRAND_BLUE,
            border: "1px solid #DCE8F3",
            fontSize: "0.85rem",
            fontWeight: 700,
          }}
        >
          {initials}
        </Avatar>

        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography
            sx={{
              color: BRAND_BLUE,
              fontWeight: 700,
              fontSize: "0.9rem",
            }}
          >
            Doctor {index + 1}
          </Typography>

          <Typography
            noWrap
            sx={{
              color: "#667085",
              fontSize: "0.78rem",
            }}
          >
            {values.name || "Doctor details"}
          </Typography>
        </Box>

        {(unread.length > 0 || serverError) && (
          <Box
            sx={{
              bgcolor: "#FFF4E5",
              color: "#9A5B00",
              px: 1,
              py: 0.4,
              borderRadius: "5px",
              fontSize: "0.7rem",
              fontWeight: 600,
            }}
          >
            Review
          </Box>
        )}

        <Typography
          sx={{
            color: "#64748B",
            fontSize: "0.75rem",
            display: { xs: "none", sm: "block" },
          }}
        >
          {expanded ? "Close" : "Open"}
        </Typography>

        <IconButton
          size="small"
          aria-label={
            expanded ? "Collapse doctor details" : "Expand doctor details"
          }
          sx={{
            color: BRAND_BLUE,
            transform: expanded ? "rotate(180deg)" : "rotate(0deg)",
            transition: "transform 0.2s",
          }}
        >
          <ExpandMoreIcon />
        </IconButton>
      </Box>

      {/* Expandable Content */}

      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <Box sx={{ p: { xs: 1.75, sm: 2 } }}>
          {unread.length > 0 && (
            <Alert severity="warning" sx={{ mb: 1.5, py: 0 }}>
              Couldn&apos;t read: {unread.join(", ")}. Please check these
              fields.
            </Alert>
          )}

          {serverError && (
            <Alert severity="error" sx={{ mb: 1.5, py: 0 }}>
              {serverError}
            </Alert>
          )}

          {/* Fields Grid */}

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, minmax(0, 1fr))",
                md: "repeat(3, minmax(0, 1fr))",
              },
              columnGap: { xs: 1.5, sm: 2, md: 2.5 },
              rowGap: 1.5,
            }}
          >
            {DOCTOR_FIELDS.filter(
              (f) => !f.visibleIf || f.visibleIf(values),
            ).map((f) => (
              <Controller
                key={f.name}
                control={control}
                name={`doctors.${index}.${f.name}` as Path<FormShape>}
                render={({ field, fieldState }) => {
                  const error = fieldState.error?.message;
                  const id = `doctor-${index}-${f.name}`;
                  const options = f.optionsKey ? optionsMap[f.optionsKey] : [];

                  const value = (field.value as string | undefined) ?? "";

                  return (
                    <Box
                      data-field-error={error ? "true" : undefined}
                      sx={{
                        minWidth: 0,
                        gridColumn: f.fullWidth ? "1 / -1" : undefined,
                      }}
                    >
                      <Typography
                        component="label"
                        htmlFor={id}
                        sx={{
                          display: "block",
                          color: "#475467",
                          fontWeight: 600,
                          fontSize: "0.78rem",
                          mb: 0.55,
                        }}
                      >
                        {f.label}
                        {f.required && (
                          <Box component="span" sx={{ color: "#D32F2F" }}>
                            {" "}
                            *
                          </Box>
                        )}
                      </Typography>

                      {f.type === "radio" ? (
                        <FormControl error={!!error} disabled={disabled}>
                          <RadioGroup
                            row
                            id={id}
                            value={value}
                            onChange={(e) => field.onChange(e.target.value)}
                            sx={{
                              minHeight: 38,
                              flexWrap: "wrap",
                            }}
                          >
                            {options.map((option) => (
                              <FormControlLabel
                                key={option}
                                value={option}
                                label={option}
                                control={
                                  <Radio
                                    size="small"
                                    sx={{
                                      color: "#AAB6C5",
                                      "&.Mui-checked": {
                                        color: BRAND_BLUE,
                                      },
                                      p: 0.5,
                                    }}
                                  />
                                }
                                sx={{
                                  mr: 1,
                                  "& .MuiFormControlLabel-label": {
                                    fontSize: "0.8rem",
                                  },
                                }}
                              />
                            ))}
                          </RadioGroup>

                          {error && <FormHelperText>{error}</FormHelperText>}
                        </FormControl>
                      ) : (
                        <TextField
                          id={id}
                          fullWidth
                          size="small"
                          value={value}
                          onChange={(e) =>
                            field.onChange(
                              f.numeric
                                ? e.target.value.replace(/\D/g, "")
                                : e.target.value,
                            )
                          }
                          onBlur={field.onBlur}
                          inputRef={field.ref}
                          error={!!error}
                          helperText={error}
                          disabled={disabled}
                          select={f.type === "select"}
                          multiline={f.type === "textarea"}
                          minRows={f.type === "textarea" ? 2 : undefined}
                          slotProps={{
                            htmlInput: {
                              maxLength: f.maxLength,
                              inputMode: f.numeric ? "numeric" : undefined,
                            },
                          }}
                          sx={inputSx}
                        >
                          {f.type === "select" &&
                            options.map((option) => (
                              <MenuItem key={option} value={option}>
                                {option}
                              </MenuItem>
                            ))}
                        </TextField>
                      )}
                    </Box>
                  );
                }}
              />
            ))}
          </Box>
        </Box>
      </Collapse>
    </Box>
  );
};

export default DoctorCard;
