"use client";
import * as React from "react";
import { Alert, Box, Button, IconButton, Typography } from "@mui/material";
import type { SxProps, Theme } from "@mui/material/styles";
import AddIcon from "@mui/icons-material/Add";
import CloseIcon from "@mui/icons-material/Close";

const BRAND_BLUE = "#005BAA";

export interface DoctorImageUploadProps {
  onSubmit: (files: File[]) => void | Promise<void>;
  isProcessing?: boolean;
  errorMessage?: string | null;
  maxSizeMB?: number;
  maxImages?: number;
  acceptedTypes?: string[];
  submitLabel?: string;
  sx?: SxProps<Theme>;
}

interface SlotProps {
  label: string;
  required?: boolean;
  file: File | null;
  accept: string;
  disabled?: boolean;
  onSelect: (file: File) => void;
  onRemove: () => void;
}

const UploadSlot: React.FC<SlotProps> = ({
  label,
  required,
  file,
  accept,
  disabled,
  onSelect,
  onRemove,
}) => {
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = React.useState(false);

  const preview = React.useMemo(
    () => (file ? URL.createObjectURL(file) : null),
    [file],
  );
  React.useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );

  const pick = (f?: File) => f && onSelect(f);

  return (
    <Box sx={{ mb: 2 }}>
      <Typography
        sx={{ fontWeight: 600, color: "#444", mb: 1, fontSize: "0.95rem" }}
      >
        {label}
        {required && <span style={{ color: "#D32F2F" }}> *</span>}
      </Typography>

      <Box
        role="button"
        tabIndex={0}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => {
          if ((e.key === "Enter" || e.key === " ") && !disabled)
            inputRef.current?.click();
        }}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (!disabled) pick(e.dataTransfer.files?.[0]);
        }}
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          minHeight: { xs: 96, sm: 110 },
          px: 2,
          borderRadius: "16px",
          border: "2px dashed",
          borderColor: dragOver ? BRAND_BLUE : "#D0D4DA",
          bgcolor: dragOver ? "#F0F7FF" : "#fff",
          color: "#5F6B7A",
          cursor: disabled ? "default" : "pointer",
          transition: "all .15s ease",
          "&:hover": { borderColor: disabled ? "#D0D4DA" : BRAND_BLUE },
        }}
      >
        {file && preview ? (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 2,
              width: "100%",
            }}
          >
            <Box
              component="img"
              src={preview}
              alt={file.name}
              sx={{
                width: 64,
                height: 64,
                objectFit: "cover",
                borderRadius: "10px",
                flexShrink: 0,
              }}
            />
            <Box sx={{ minWidth: 0, flex: 1 }}>
              <Typography noWrap sx={{ fontWeight: 600, color: "#333" }}>
                {file.name}
              </Typography>
              <Typography sx={{ fontSize: "0.8rem" }}>
                {(file.size / 1024 / 1024).toFixed(2)} MB
              </Typography>
            </Box>
            <IconButton
              aria-label="Remove image"
              disabled={disabled}
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        ) : (
          <Typography sx={{ fontSize: { xs: "1rem", sm: "1.15rem" } }}>
             Upload Image
          </Typography>
        )}

        <input
          ref={inputRef}
          type="file"
          accept={accept}
          hidden
          onChange={(e) => {
            console.log("e---------", e.target.files?.[0]);
            pick(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
      </Box>
    </Box>
  );
};

export const ProcessingCard: React.FC = () => (
  <Box
    sx={{
      textAlign: "center",
      py: 4,
      px: 2,
      borderRadius: "20px",
      bgcolor: "#fff",
      boxShadow: "0 2px 12px rgba(0,0,0,0.08)",
      color: BRAND_BLUE,
    }}
  >
    <Typography sx={{ fontWeight: 600, fontSize: "1.15rem", mb: 3 }}>
       Processing Image...
    </Typography>
    <Typography sx={{ fontWeight: 600, fontSize: "1.1rem" }}>
      Extracting Doctor Information
    </Typography>
  </Box>
);

const DoctorImageUpload: React.FC<DoctorImageUploadProps> = ({
  onSubmit,
  isProcessing = false,
  errorMessage,
  maxSizeMB = 5,
  maxImages = 5,
  acceptedTypes = ["image/jpeg", "image/png"],
  submitLabel = "Submit",
  sx,
}) => {
  const [files, setFiles] = React.useState<(File | null)[]>([null]);
  const [localError, setLocalError] = React.useState<string | null>(null);

  console.log(">>>> files", files);

  const accept = acceptedTypes.join(",");
  const canAddMore = files.length < maxImages;

  const handleSelect = async (index: number, file: File) => {
    console.log("file-----------", file);

    const auditPayload = {
      api_key: "audit_insertion",
      user_id: "CF41272",
      user_name: "gopi",
      source_channel: "SSA",
      ocrid: "123",
      status: "initiated",
      created_by: "gopi",
      file_information: file,
    };

    if (!acceptedTypes.includes(file.type)) {
      setLocalError("Only JPG, JPEG and PNG images are supported.");
      return;
    }

    if (file.size > maxSizeMB * 1024 * 1024) {
      setLocalError(`Image size should not exceed ${maxSizeMB} MB.`);
      return;
    }
    setLocalError(null);
    setFiles((prev) => prev.map((f, i) => (i === index ? file : f)));
  };

  const handleRemove = (index: number) => {
    setFiles((prev) => {
      if (index > 0) return prev.filter((_, i) => i !== index);
      return prev.map((f, i) => (i === index ? null : f));
    });
  };

  const handleSubmit = async () => {
    console.log("handleSubmit--------------");
    const auditPayload = {
      api_key: "audit_insertion",
      user_id: "CF41272",
      user_name: "gopi",
      source_channel: "SSA",
      ocrid: "123",
      status: "uploaded",
      created_by: "gopi",
    };

    const selected = files.filter((f): f is File => !!f);
    if (!selected.length) {
      auditPayload["status"] = "failed";
      setLocalError("Please upload at least one image.");
    }
    setLocalError(null);
    await onSubmit(selected);
  };

  if (isProcessing) return <ProcessingCard />;

  const shownError = localError ?? errorMessage;

  return (
    <Box sx={[{ width: "100%" }, ...(Array.isArray(sx) ? sx : [sx])]}>
      {files.map((file, i) => (
        <UploadSlot
          key={i}
          label={i === 0 ? "Image 1" : `Image ${i + 1} (Optional)`}
          required={i === 0}
          file={file}
          accept={accept}
          onSelect={(f) => handleSelect(i, f)}
          onRemove={() => handleRemove(i)}
        />
      ))}

      {canAddMore && (
        <Button
          onClick={() => setFiles((prev) => [...prev, null])}
          startIcon={<AddIcon sx={{ color: "#7B61B5" }} />}
          sx={{
            color: BRAND_BLUE,
            fontWeight: 700,
            fontSize: { xs: "1rem", sm: "1.1rem" },
            textTransform: "none",
            px: 0,
            mb: 2,
            "&:hover": { bgcolor: "transparent", textDecoration: "underline" },
          }}
        >
          Add One More Image
        </Button>
      )}

      {shownError && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: "12px" }}>
          {shownError}
        </Alert>
      )}

      <Button
        fullWidth
        disableElevation
        variant="contained"
        onClick={handleSubmit}
        sx={{
          py: 1.6,
          borderRadius: "12px",
          bgcolor: BRAND_BLUE,
          fontWeight: 700,
          fontSize: "1.1rem",
          textTransform: "none",
          "&:hover": { bgcolor: "#004A8C" },
        }}
      >
        {submitLabel}
      </Button>
    </Box>
  );
};

export default DoctorImageUpload;
