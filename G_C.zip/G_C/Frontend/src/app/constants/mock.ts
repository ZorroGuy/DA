export const payloadData = {
  "request_id": "abc",
  "client_id": "fbfb60ae-226c-4c10-bdeb-b3a8caa4060a",
  "prompt_id": 5,
  "type": "sync",
  "status": "Initiated",
  "ack_id": "",
  "checksum": "",
  "dms_id": "",
  "dms_download": true,
  "pdf_base_64": "",
  "image_base_64": "",
  "image_type": "jpg",
  "prompt_version": 1
};

