import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  //console.log("process.env.DMS_API_URL", process.env.DMS_API_URL);
  try {
    const incomingFormData = await req.formData();
    const file = incomingFormData.get("File") as File | null;
    const metadataRaw = incomingFormData.get("Text") as string | null;

    if (!file || !metadataRaw) {
      return NextResponse.json(
        { error: "Missing required File or metadata" },
        { status: 400 },
      );
    }

    const upstreamFormData = new FormData();
     upstreamFormData.append(
      "api_key",
      "file_upload",
    );
    upstreamFormData.append("Text", metadataRaw);
    upstreamFormData.append("File", file, file.name);

    const response = await fetch(process.env.DMS_API_URL!, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.DMS_BEARER_TOKEN}`,
      },
      body: upstreamFormData,
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      return NextResponse.json(
        { error: "DMS Upload Failed", details: data },
        { status: response.status },
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error("DMS Upload Route Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error during DMS upload" },
      { status: 500 },
    );
  }
}
