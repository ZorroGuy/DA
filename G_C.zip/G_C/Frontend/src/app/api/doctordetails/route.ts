import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const payload = await req.json();

    if (!payload?.submitted_data || !Array.isArray(payload.submitted_data) || payload.submitted_data.length === 0) {
      return NextResponse.json(
        { message: "submitted_data is required and cannot be empty" },
        { status: 400 },
      );
    }

    const response = await fetch(process.env.DMS_API_URL!, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.DMS_BEARER_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => null);

    if (response.status === 409) {
      return NextResponse.json(
        {
          message: data?.message || "Duplicate Data entry",
          details: data,
        },
        { status: 409 },
      );
    }

    if (!response.ok) {
      return NextResponse.json(
        {
          message: data?.message || data?.error || "Failed to save doctors",
          details: data,
        },
        { status: response.status },
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error("Doctor Details API Route Error:", error);
    return NextResponse.json(
      { message: "Internal Server Error while saving doctor details" },
      { status: 500 },
    );
  }
}