import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body?.dms_id) {
      return NextResponse.json(
        { error: "dms_id is required" },
        { status: 400 },
      );
    }

    const response = await fetch(process.env.VERTEX_OCR_API_URL!, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.VERTEX_OCR_TOKEN}`,
      },
      body: JSON.stringify(body),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      return NextResponse.json(
        { error: "Doctor OCR Failed", details: data },
        { status: response.status },
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    console.error("Doctor OCR Route Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error during OCR processing" },
      { status: 500 },
    );
  }
}
