import mongo from '../../utils/pgConnection/mongooseConnect.js';
import { randomUUID } from 'crypto';
import { Long } from 'mongodb';
import { getDmsUpload } from './dms_upload.js';
import { insertDoctorAuditLog } from './dms_upload.js';

const DOCTOR_COLLECTION = 'doctor_master_details';
const AUDIT_COLLECTION = 'doctor_ocr_audit';

const isValidMobile = (value) => {
  return /^[6-9]\d{9}$/.test(String(value || ''));
};

const isValidPincode = (value) => {
  return /^\d{6}$/.test(String(value || ''));
};

const isValidDoctor = (doctor) => {
  return Boolean(
    doctor?.name?.trim() &&
    doctor?.degree?.trim() &&
    doctor?.contact_number &&
    isValidMobile(doctor.contact_number) &&
    doctor?.clinicclsal_hospital_pincode &&
    isValidPincode(doctor.clinical_hospital_pincode)
  );
};

const getDoctorData = (doctor) => {
  if (!doctor || typeof doctor !== 'object' || Array.isArray(doctor)) {
    return null;
  }

  return {
    name: doctor.name,
    degree: doctor.degree,
    speciality: doctor.speciality ?? null,
    contact_numbers: Array.isArray(doctor.contact_numbers) ? doctor.contact_numbers : [],
    registration_no: doctor.registration_no ?? null,
    registration_year: doctor.registration_year ?? null,
    years_of_experience: doctor.years_of_experience ?? null,
    medical_council: doctor.medical_council ?? null,
    practice_type: doctor.practice_type ?? null,
    clinic_hospital_name: doctor.clinic_hospital_name ?? null,
    clinic_hospital_address: doctor.clinic_hospital_address ?? null,
    clinic_hospital_pincode: doctor.clinic_hospital_pincode ?? null,
  };
};

// Doctor OCR Service

const doctorOcrService = async (req, res) => {
  try {
    const { api_key } = req.body;
    switch (api_key) {
      case 'file_upload': {
        if (!req.body?.Text || !req.files?.length) {
          return res.status(400).json({
            success: false,
            message: "Both 'Text' metadata and 'File' are required.",
          });
        }
        const metadata = JSON.parse(req.body.Text);
        const file = req.files[0];
        const dmsResponse = await getDmsUpload(metadata, file);
        return res.status(200).json({
          success: true,
          message: 'DMS upload successful',
          dms_id: dmsResponse,
        });
      }

      case 'audit_insertion': {
        const {
          user_id,
          user_name,
          source_channel,
          status,
          file_information,
          ocr_request_payload,
          ocr_response,
          registration_nos,
          doctor_count,
          error_message,
          created_by,
        } = req.body;

        if (!user_id || !user_name || !source_channel || !status || !created_by) {
          return res.status(400).json({
            success: false,
            message: 'Missing required audit information',
          });
        }

        if (!['SSA', 'FSA'].includes(source_channel)) {
          return res.status(400).json({
            success: false,
            message: 'Invalid source channel',
          });
        }

        const auditData = {
          id: Long.fromNumber(Date.now()),
          user_id,
          user_name,
          source_channel,
          status,
          file_information: file_information !== undefined ? JSON.stringify(file_information) : '',
          ocr_request_payload:
            ocr_request_payload !== undefined ? JSON.stringify(ocr_request_payload) : '',
          ocr_response: ocr_response !== undefined ? JSON.stringify(ocr_response) : '',
          registration_nos: Array.isArray(registration_nos)
            ? registration_nos.join(',')
            : registration_nos || '',
          doctor_count: Number(doctor_count || 0),
          error_message: error_message || '',
          created_by,
          created_at: new Date(),
        };

        const result = await mongo.doctorOcrDb.collection(AUDIT_COLLECTION).insertOne(auditData);

        return res.status(201).json({
          success: true,
          message: 'OCR audit inserted successfully',
          insertedId: result.insertedId,
        });
      }

      case 'audit_retrival': {
        const {
          user_id,
          source_channel,
          status,
          from_date,
          to_date,
          page = 1,
          limit = 20,
        } = req.body;

        const currentPage = Math.max(1, Number(page) || 1);
        const pageLimit = Math.min(100, Math.max(1, Number(limit) || 20));

        const query = {};

        if (user_id) query.user_id = user_id;
        if (source_channel) query.source_channel = source_channel;
        if (status) query.status = status;

        if (from_date || to_date) {
          query.created_at = {};

          if (from_date) {
            const startDate = new Date(from_date);

            if (Number.isNaN(startDate.getTime())) {
              return res.status(400).json({
                success: false,
                message: 'Invalid from_date',
              });
            }

            query.created_at.$gte = startDate;
          }

          if (to_date) {
            const endDate = new Date(to_date);

            if (Number.isNaN(endDate.getTime())) {
              return res.status(400).json({
                success: false,
                message: 'Invalid to_date',
              });
            }

            query.created_at.$lte = endDate;
          }
        }

        const collection = mongo.doctorOcrDb.collection(AUDIT_COLLECTION);

        const [audits, totalRecords] = await Promise.all([
          collection
            .find(query)
            .sort({ created_at: -1 })
            .skip((currentPage - 1) * pageLimit)
            .limit(pageLimit)
            .toArray(),

          collection.countDocuments(query),
        ]);

        return res.status(200).json({
          success: true,
          message: 'OCR audit records fetched successfully',
          pagination: {
            page: currentPage,
            limit: pageLimit,
            totalRecords,
            totalPages: Math.ceil(totalRecords / pageLimit),
          },
          data: audits,
        });
      }

      case 'doctor_detail_entry': {
        const { created_employee_id, source_channel, ocrid, original_data, submitted_data } =
          req.body;

        const createAudit = async ({
          status,
          doctor_count,
          registration_nos = [],
          error_message = '',
        }) => {
          try {
            await insertDoctorAuditLog({
              user_id: created_employee_id || '',
              user_name: created_employee_id || '',
              source_channel: source_channel || '',
              status,
              registration_nos,
              doctor_count,
              ocr_request_payload: original_data || [],
              ocr_response: submitted_data || [],
              error_message,
              created_by: created_employee_id || '',
            });
          } catch (auditError) {
            console.error('Audit Log Insertion Failed:', auditError);
          }
        };
        if (!created_employee_id || !ocrid || !['SSA', 'FSA'].includes(source_channel)) {
          await createAudit({
            status: 'VALIDATION_FAILED',
            error_message: 'Valid employee ID, source channel, and OCR ID are required',
          });

          return res.status(400).json({
            success: false,
            message: 'Valid employee ID, source channel, and OCR ID are required',
          });
        }

        if (
          !Array.isArray(original_data) ||
          !Array.isArray(submitted_data) ||
          submitted_data.length === 0 ||
          original_data.length !== submitted_data.length
        ) {
          await createAudit({
            status: 'VALIDATION_FAILED',
            error_message: 'Please provide valid original and submitted doctor details',
          });

          return res.status(400).json({
            success: false,
            message: 'Please provide valid original and submitted doctor details',
          });
        }

        const collection = mongo.doctorOcrDb.collection(DOCTOR_COLLECTION);

        const doctorDocuments = [];
        const validSubmittedPayload = [];
        const validOriginalPayload = [];
        const duplicateRecords = [];
        const duplicateSubmittedPayload = [];
        const duplicateOriginalPayload = [];

        const formatContactNumber = (numbers = []) =>
          numbers
            .filter(
              (number) => number !== null && number !== undefined && String(number).trim() !== ''
            )
            .join(', ');

        for (let index = 0; index < submitted_data.length; index++) {
          const doctor = submitted_data[index];
          const originalDoctor = original_data[index];

          if (
            !doctor.name ||
            !doctor.degree ||
            !doctor.clinic_hospital_pincode ||
            !doctor.contact_numbers?.length
          ) {
            return res.status(400).json({
              success: false,
              message: `Required fields missing for doctor ${index + 1}`,
            });
          }

          const contactNumber = formatContactNumber(doctor.contact_numbers);

          const registrationNumber = doctor.registration_no
            ? String(doctor.registration_no).trim()
            : '';

          let isDuplicate = false;

          if (registrationNumber) {
            const existingRegistration = await collection.findOne({
              registration_number: registrationNumber,
            });

            if (existingRegistration) {
              isDuplicate = true;
              duplicateRecords.push({
                doctor_number: index + 1,
                duplicate_field: 'registration_number',
                message: 'Registration number already exists',
              });
            }
          }

          if (!isDuplicate && contactNumber) {
            const existingDoctor = await collection.findOne({
              contact_number: contactNumber,
              degree: doctor.degree,
            });

            if (existingDoctor) {
              isDuplicate = true;
              duplicateRecords.push({
                doctor_number: index + 1,
                duplicate_field: 'contact_number_degree',
                message: 'Mobile number with same degree already exists',
              });
            }
          }

          if (isDuplicate) {
            duplicateSubmittedPayload.push(doctor);
            duplicateOriginalPayload.push(originalDoctor);
            continue;
          }

          validSubmittedPayload.push(doctor);
          validOriginalPayload.push(originalDoctor);

          doctorDocuments.push({
            uuid: randomUUID(),
            ocrid,
            doctor_sequence: index + 1,
            created_employee_id,
            source_channel,

            name: String(doctor.name).trim(),
            degree: String(doctor.degree).trim(),
            speciality: doctor.speciality || '',

            contact_number: contactNumber,
            registration_number: registrationNumber,

            registration_year: doctor.registration_year ? Number(doctor.registration_year) : null,

            years_of_experience: doctor.years_of_experience
              ? Number(doctor.years_of_experience)
              : null,

            medical_council: doctor.medical_council || '',
            practice_type: doctor.practice_type || '',

            clinical_hospital_name: doctor.clinic_hospital_name || '',

            clinical_hospital_address: doctor.clinic_hospital_address || '',

            clinical_hospital_pincode: String(doctor.clinic_hospital_pincode).trim(),

            created_at: new Date(),
          });
        }

        if (duplicateRecords.length > 0) {
          const duplicateRegNos = duplicateRecords
            .map((item) => item.registration_number)
            .filter(Boolean);
          await createAudit({
            status: 'DUPLICATE_FOUND',
            doctor_count: duplicateRecords.length,
            error_message: JSON.stringify(duplicateRecords),
          });
          if (doctorDocuments.length === 0) {
            return res.status(409).json({
              success: false,
              message: 'Duplicate data entry',
              duplicates: duplicateRecords,
            });
          }
        }

        try {
          const result = await collection.insertMany(doctorDocuments, { ordered: true });
          const validRegistrationNos = doctorDocuments
            .map((doc) => doc.registration_number)
            .filter(Boolean);

          await createAudit({
            status: 'SUCCESS',
            doctor_count: doctorDocuments.length,
            registration_nos: validRegistrationNos,
            request_payload: validOriginalPayload,
            response_payload: validSubmittedPayload,
          });

          return res.status(201).json({
            success: true,
            message:
              duplicateRecords.length > 0
                ? 'Valid doctor details inserted; duplicate records skipped and logged'
                : 'Doctor details inserted successfully',
            doctor_count: doctorDocuments.length,
            insertedIds: Object.values(result.insertedIds),
            duplicate_count: duplicateRecords.length,
            duplicates: duplicateRecords,
          });
        } catch (error) {
          await createAudit({
            status: 'DATABASE_ERROR',
            error_message: error.message,
          });

          console.error('MongoDB Error:', error);

          if (error?.writeErrors?.length) {
            const mongoErrors = error.writeErrors.map((item) => {
              const err = item.err || item;

              return {
                doctor_number: item.index + 1,
                error_code: item.code || err.code,
                error_message: item.errmsg || err.errmsg || err.message,
                details:
                  err.errInfo?.details ||
                  err.errInfo ||
                  item.errInfo?.details ||
                  item.errInfo ||
                  null,
              };
            });

            return res.status(400).json({
              success: false,
              error_code: 'MONGODB_WRITE_ERROR',
              message: 'Doctor details insertion failed',
              errors: mongoErrors,
            });
          }

          if (error.code === 121) {
            return res.status(400).json({
              success: false,
              error_code: 'VALIDATION_ERROR',
              message: 'MongoDB document validation failed',
              details: error.errInfo?.details || error.errInfo || error.message,
            });
          }

          if (error.code === 11000) {
            return res.status(409).json({
              success: false,
              error_code: 'DUPLICATE_KEY',
              message: 'Duplicate record already exists',
              details: error.keyValue || error.message,
            });
          }

          return res.status(500).json({
            success: false,
            error_code: 'DATABASE_ERROR',
            message: 'Something went wrong while inserting doctor details',
            details: error.message,
          });
        }
      }

      case 'fetch_doctor_detail': {
        const {
          uuid,
          ocrid,
          doctor_sequence,
          created_employee_id,
          source_channel,
          name,
          degree,
          speciality,
          contact_number,
          registration_number,
          registration_year,
          years_of_experience,
          medical_council,
          practice_type,
          clinical_hospital_name,
          clinical_hospital_address,
          clinical_hospital_pincode,
          updated_by,
        } = req.body;

        // Build dynamic search query
        const searchQuery = {};

        const filters = {
          uuid,
          ocrid,
          doctor_sequence,
          created_employee_id,
          source_channel,
          name,
          degree,
          speciality,
          contact_number,
          registration_number,
          registration_year,
          years_of_experience,
          medical_council,
          practice_type,
          clinical_hospital_name,
          clinical_hospital_address,
          clinical_hospital_pincode,
          updated_by,
        };

        // Add only provided filters
        Object.entries(filters).forEach(([key, value]) => {
          if (value !== undefined && value !== null && String(value).trim() !== '') {
            searchQuery[key] = value;
          }
        });

        const collection = mongo.doctorOcrDb.collection(DOCTOR_COLLECTION);

        // Fetch matching records
        const doctors = await collection.find(searchQuery).toArray();

        if (doctors.length === 0) {
          return res.status(404).json({
            success: false,
            message: 'Doctor details not found',
            data: [],
          });
        }

        return res.status(200).json({
          success: true,
          message: 'Doctor details fetched successfully',
          doctor_count: doctors.length,
          data: doctors,
        });
      }

      default:
        return res.status(400).json({
          success: false,
          message: 'Invalid api_key',
          supported_api_keys: [
            'audit_insertion',
            'audit_retrival',
            'doctor_detail_entry',
            'fetch_doctor_detail',
            'file_upload',
          ],
        });
    }
  } catch (error) {
    console.error('[Doctor OCR API Error]:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

export default doctorOcrService;
