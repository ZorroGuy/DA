import axios from "axios";
import FormData from "form-data";
import mongo from "../../utils/pgConnection/mongooseConnect.js";
import { Long } from "mongodb";
import { environent } from "../../Config/commonConfig.js";

export const getDmsUpload = async (metadata, file) => {
  const env = process.env.NODE_ENV;
  const baseConfig = environent[env]?.DMS_OCR?.DMSUPLOAD;
   let token = process.constants.URL_TOKENS[baseConfig.headers.Authorization];

  if (!baseConfig) {
    throw new Error(`DMSUPLOAD config not found for environment: ${env}`);
  }

  try {
    const formData = new FormData();

    formData.append("data", JSON.stringify(metadata));
    formData.append("image", file.buffer, {
      filename: file.originalname,
      contentType: file.mimetype || "application/pdf",
    });

    const headers = {
      ...baseConfig.headers,
      "Authorization":token,
      ...formData.getHeaders(),
    };

    const response = await axios({
      method: baseConfig.method || "post",
      url: baseConfig.url,
      data: formData,
      headers,
      maxBodyLength: baseConfig.maxBodyLength ?? Infinity,
      maxContentLength: baseConfig.maxContentLength ?? Infinity,
    });

    return response.data;
  } catch (error) {
    console.error("DMS Upload Error:", error.response?.data || error.message);
    throw error;
  }
};

export const insertDoctorAuditLog = async ({
  user_id,
  user_name,
  source_channel,
  status,
  registration_nos,
  doctor_count,
  ocr_request_payload,
  ocr_response,
  error_message = "",
  created_by,
}) => {
  const auditCollection = mongo.doctorOcrDb.collection("doctor_ocr_audit");

  const auditData = {
    id: Long.fromNumber(Date.now()),
    user_id,
    user_name,
    source_channel,
    status,
    file_information: "",
    ocr_request_payload: JSON.stringify(ocr_request_payload || {}),
    ocr_response: JSON.stringify(ocr_response || {}),
    registration_nos: Array.isArray(registration_nos)
      ? registration_nos.join(",")
      : registration_nos || "",
    doctor_count: Number(doctor_count || 0),
    error_message,
    created_by,
    created_at: new Date(),
  };

  return await auditCollection.insertOne(auditData);
};